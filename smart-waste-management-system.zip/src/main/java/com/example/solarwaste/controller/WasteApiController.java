
package com.example.solarwaste.controller;

import com.example.solarwaste.entity.WasteRecord;
import com.example.solarwaste.service.WasteService;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/waste")
public class WasteApiController {

    private final WasteService wasteService;

    public WasteApiController(WasteService wasteService) {
        this.wasteService = wasteService;
    }

    @GetMapping
    public List<WasteRecord> getAllWaste() {
        return wasteService.getAllWaste();
    }

    @PostMapping
    public WasteRecord addWaste(@RequestBody WasteRecord record) {
        return wasteService.saveWaste(record);
    }

    @DeleteMapping("/{id}")
    public void deleteWaste(@PathVariable Long id) {
        wasteService.deleteWaste(id);
    }
}
