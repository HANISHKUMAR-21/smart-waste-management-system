package com.example.solarwaste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolarwasteApplicationTests {

	@Test
	void contextLoads() {
	}

}
